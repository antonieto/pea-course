for (int i = 0; i < ErrorList.size(); i++){ 
    if(ErrorList[i].getCount() > 1) ErrorList[i].printLog();
  }